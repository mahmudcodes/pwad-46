<footer>
	<div class="wrap-footer zerogrid">
		<div class="row block09">
			<?php  
				dynamic_sidebar('footer');
			?>
			
			
		</div>
		
		<?php  
			/*
			wp_nav_menu(array(
				'theme_location' => 'footer',
				'container_class' => 'block09'
			));
			*/
		?>

		<div class="row copyright">
			<p>Copyright © 2013 - <a href="https://www.zerotheme.com/432/free-responsive-html5-css3-website-templates.html" target="_blank">Free Html5 Templates</a> by <a href="https://www.zerotheme.com" target="_blank">Zerotheme.com</a></p>
		</div>
	</div>
</footer>
<?php wp_footer(); ?>
</body></html>